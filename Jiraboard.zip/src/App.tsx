import "./App.css";
import KanbanBoard from "./Components/KanbanBoard";

function App() {
  return (
    <>
      <KanbanBoard/>
    </>
  );
}

export default App;
